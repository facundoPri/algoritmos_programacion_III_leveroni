#!/bin/bash
vm/squeak-jit CuisUniversity-4532.image