#!/bin/bash
vm/squeak CuisUniversity-4532.image