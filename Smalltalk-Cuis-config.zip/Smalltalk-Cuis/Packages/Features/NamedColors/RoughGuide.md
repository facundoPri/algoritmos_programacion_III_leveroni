Cuis-NamedColors
================
# Techniques of Interest

- Create custom color dictionaries

- Make your color dictionary the system color dictionary

- Note method Color>>doesNotUnderstand: which shows how new colors are created by name using the current color dictionary.
